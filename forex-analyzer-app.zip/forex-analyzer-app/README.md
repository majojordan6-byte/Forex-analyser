# Forex Analyzer App

Simple live Forex market analysis tools.

## Files included

| File | What it is |
|------|------------|
| **forex_phone.html** | Phone-friendly web app. Just open it in your phone browser (or Add to Home Screen). No installation needed. |
| **forex_app.py** | Streamlit version (richer analysis + charts). Deploy free on Streamlit Cloud. |
| **forex_analyzer.py** | Command-line version that runs continuously and can send Telegram alerts. |
| **requirements.txt** | Python packages needed for the Streamlit & CLI versions. |

## Quick start

### 1. Phone version (easiest)
Just open `forex_phone.html` on your phone.

### 2. Streamlit version (online)
1. Create a free GitHub repo and upload `forex_app.py` + `requirements.txt`
2. Go to https://share.streamlit.io → New app → select your repo → Deploy
3. You get a public link you can open on your phone anytime

### 3. Command-line version
```bash
pip install -r requirements.txt
python forex_analyzer.py
```

## Notes
- Data comes from free biquote (MetaTrader 5 feed)
- For education only – not financial advice
