#!/usr/bin/env python3
"""
Forex Market Analyzer - Real-time analysis + on-the-spot alerts
==============================================================
Uses free biquote data (no API key needed).
Analyzes major pairs with technical indicators and prints clear signals.

Features:
- Live quotes + 1h / 4h / daily context
- RSI, Moving Averages, MACD, Bollinger Bands
- Simple trend + signal (BUY / SELL / NEUTRAL)
- Runs continuously and alerts on strong signals or big moves
- Easy to extend with Telegram / Discord later

How to run:
    pip install biquote pandas numpy ta
    python forex_analyzer.py

Optional: set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID environment variables
to receive alerts on Telegram.
"""

import time
import os
from datetime import datetime, timezone
from typing import Dict, List, Optional

import pandas as pd
import numpy as np

try:
    from biquote import Biquote
except ImportError:
    print("Please install: pip install biquote")
    raise

try:
    import ta
except ImportError:
    print("Please install: pip install ta")
    raise

# ====================== CONFIG ======================
PAIRS = [
    "EURUSD",
    "GBPUSD",
    "USDJPY",
    "AUDUSD",
    "USDCAD",
    "USDCHF",
    "NZDUSD",
    "EURGBP",
    "EURJPY",
    "GBPJPY",
    "XAUUSD",  # Gold (very popular with forex traders)
]

CHECK_INTERVAL_SECONDS = 60 * 3          # Check every 3 minutes
ALERT_RSI_OVERBOUGHT = 70
ALERT_RSI_OVERSOLD = 30
MIN_MOVE_PERCENT_ALERT = 0.25            # Alert if pair moved this % since last check
STRONG_SIGNAL_ONLY = False               # If True, only alert on strong signals

# Optional Telegram (leave empty to disable)
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# ====================================================

bq = Biquote()
last_prices: Dict[str, float] = {}
last_signals: Dict[str, str] = {}


def send_telegram(message: str) -> None:
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return
    try:
        import requests
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        requests.post(url, json={
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "HTML"
        }, timeout=10)
    except Exception as e:
        print(f"[Telegram error] {e}")


def get_ohlc_df(symbol: str, interval: str = "1h", limit: int = 100) -> Optional[pd.DataFrame]:
    try:
        data = bq.ohlc(symbol, interval=interval, limit=limit)
        if not data:
            return None
        df = pd.DataFrame(data)
        df["openTime"] = pd.to_datetime(df["openTime"])
        df = df.sort_values("openTime").reset_index(drop=True)
        df.rename(columns={
            "open": "Open", "high": "High", "low": "Low",
            "close": "Close", "tickVolume": "Volume"
        }, inplace=True)
        return df
    except Exception as e:
        print(f"  Error fetching OHLC for {symbol}: {e}")
        return None


def analyze_pair(symbol: str) -> Dict:
    """Return a clean analysis dictionary for one pair."""
    result = {
        "symbol": symbol,
        "mid": None,
        "bid": None,
        "ask": None,
        "day_change_pct": None,
        "spread": None,
        "trend_1h": "N/A",
        "trend_4h": "N/A",
        "rsi_14": None,
        "macd_signal": "N/A",
        "ma_signal": "N/A",
        "bb_position": "N/A",
        "overall_signal": "NEUTRAL",
        "strength": 0,
        "summary": "",
        "error": None
    }

    # Live tick
    try:
        tick = bq.tick(symbol)
        result["mid"] = tick.get("mid")
        result["bid"] = tick.get("bid")
        result["ask"] = tick.get("ask")
        result["day_change_pct"] = tick.get("dayDiffPercent")
        result["spread"] = tick.get("spread")
        result["market_state"] = tick.get("marketState", "unknown")
    except Exception as e:
        result["error"] = f"Tick error: {e}"
        return result

    # 1h analysis
    df_1h = get_ohlc_df(symbol, "1h", 120)
    if df_1h is not None and len(df_1h) > 30:
        close = df_1h["Close"]

        # RSI
        rsi = ta.momentum.RSIIndicator(close, window=14).rsi()
        result["rsi_14"] = round(float(rsi.iloc[-1]), 1)

        # Moving averages
        sma20 = close.rolling(20).mean()
        sma50 = close.rolling(50).mean()
        ema12 = close.ewm(span=12).mean()
        ema26 = close.ewm(span=26).mean()

        last_close = close.iloc[-1]
        last_sma20 = sma20.iloc[-1]
        last_sma50 = sma50.iloc[-1]

        if last_close > last_sma20 > last_sma50:
            result["ma_signal"] = "BULLISH"
            result["trend_1h"] = "UP"
        elif last_close < last_sma20 < last_sma50:
            result["ma_signal"] = "BEARISH"
            result["trend_1h"] = "DOWN"
        else:
            result["ma_signal"] = "MIXED"
            result["trend_1h"] = "SIDEWAYS"

        # MACD
        macd = ta.trend.MACD(close)
        macd_line = macd.macd()
        signal_line = macd.macd_signal()
        hist = macd.macd_diff()

        if macd_line.iloc[-1] > signal_line.iloc[-1] and hist.iloc[-1] > 0:
            result["macd_signal"] = "BULLISH"
        elif macd_line.iloc[-1] < signal_line.iloc[-1] and hist.iloc[-1] < 0:
            result["macd_signal"] = "BEARISH"
        else:
            result["macd_signal"] = "NEUTRAL"

        # Bollinger Bands position
        bb = ta.volatility.BollingerBands(close, window=20, window_dev=2)
        upper = bb.bollinger_hband().iloc[-1]
        lower = bb.bollinger_lband().iloc[-1]
        mid_bb = bb.bollinger_mavg().iloc[-1]

        if last_close >= upper:
            result["bb_position"] = "ABOVE UPPER (overbought zone)"
        elif last_close <= lower:
            result["bb_position"] = "BELOW LOWER (oversold zone)"
        elif last_close > mid_bb:
            result["bb_position"] = "Upper half"
        else:
            result["bb_position"] = "Lower half"

    # 4h quick trend
    df_4h = get_ohlc_df(symbol, "4h", 50)
    if df_4h is not None and len(df_4h) > 20:
        close4 = df_4h["Close"]
        sma20_4 = close4.rolling(20).mean()
        if close4.iloc[-1] > sma20_4.iloc[-1]:
            result["trend_4h"] = "UP"
        else:
            result["trend_4h"] = "DOWN"

    # Overall signal logic
    score = 0
    reasons = []

    rsi = result["rsi_14"]
    if rsi is not None:
        if rsi <= ALERT_RSI_OVERSOLD:
            score += 2
            reasons.append(f"RSI oversold ({rsi})")
        elif rsi >= ALERT_RSI_OVERBOUGHT:
            score -= 2
            reasons.append(f"RSI overbought ({rsi})")
        elif rsi < 45:
            score += 0.5
        elif rsi > 55:
            score -= 0.5

    if result["ma_signal"] == "BULLISH":
        score += 1.5
        reasons.append("MA bullish alignment")
    elif result["ma_signal"] == "BEARISH":
        score -= 1.5
        reasons.append("MA bearish alignment")

    if result["macd_signal"] == "BULLISH":
        score += 1
        reasons.append("MACD bullish")
    elif result["macd_signal"] == "BEARISH":
        score -= 1
        reasons.append("MACD bearish")

    if result["trend_4h"] == "UP":
        score += 0.5
    elif result["trend_4h"] == "DOWN":
        score -= 0.5

    result["strength"] = round(score, 1)

    if score >= 2.5:
        result["overall_signal"] = "STRONG BUY"
    elif score >= 1.0:
        result["overall_signal"] = "BUY"
    elif score <= -2.5:
        result["overall_signal"] = "STRONG SELL"
    elif score <= -1.0:
        result["overall_signal"] = "SELL"
    else:
        result["overall_signal"] = "NEUTRAL"

    result["summary"] = " | ".join(reasons) if reasons else "No strong technical confluence"

    return result


def format_report(analyses: List[Dict]) -> str:
    lines = []
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines.append(f"{'='*70}")
    lines.append(f"  FOREX MARKET SNAPSHOT  •  {now}")
    lines.append(f"{'='*70}")

    # Header
    lines.append(f"{'PAIR':<10} {'PRICE':>10} {'DAY%':>7} {'RSI':>6} {'1H':<8} {'4H':<6} {'SIGNAL':<12} {'STRENGTH'}")
    lines.append("-" * 70)

    for a in analyses:
        if a.get("error"):
            lines.append(f"{a['symbol']:<10} ERROR: {a['error']}")
            continue

        price = f"{a['mid']:.5f}" if a["mid"] else "N/A"
        day = f"{a['day_change_pct']:+.2f}%" if a["day_change_pct"] is not None else "N/A"
        rsi = f"{a['rsi_14']:.1f}" if a["rsi_14"] is not None else "N/A"
        signal = a["overall_signal"]
        strength = f"{a['strength']:+.1f}"

        lines.append(
            f"{a['symbol']:<10} {price:>10} {day:>7} {rsi:>6} "
            f"{a['trend_1h']:<8} {a['trend_4h']:<6} {signal:<12} {strength}"
        )

    lines.append("-" * 70)
    lines.append("")

    # Detailed strong signals
    strong = [a for a in analyses if a["overall_signal"] in ("STRONG BUY", "STRONG SELL", "BUY", "SELL")]
    if strong:
        lines.append("🔔 ACTIVE SIGNALS:")
        for a in strong:
            lines.append(f"  • {a['symbol']} → {a['overall_signal']} ({a['strength']:+.1f})")
            lines.append(f"    {a['summary']}")
            if a.get("bb_position"):
                lines.append(f"    Bollinger: {a['bb_position']}")
        lines.append("")

    lines.append("Legend: Strength ≥ +2.5 = STRONG BUY | ≤ -2.5 = STRONG SELL")
    lines.append("Data source: biquote (MetaTrader 5 feed) • Free • No API key")
    lines.append(f"{'='*70}")

    return "\n".join(lines)


def check_for_alerts(analyses: List[Dict]) -> None:
    """Send alerts on strong signals or big price moves."""
    for a in analyses:
        symbol = a["symbol"]
        signal = a["overall_signal"]
        mid = a.get("mid")

        # Strong signal alert
        is_strong = signal in ("STRONG BUY", "STRONG SELL")
        is_actionable = signal in ("BUY", "SELL", "STRONG BUY", "STRONG SELL")

        if (STRONG_SIGNAL_ONLY and is_strong) or (not STRONG_SIGNAL_ONLY and is_actionable):
            prev = last_signals.get(symbol)
            if prev != signal:
                msg = (
                    f"🚨 <b>{symbol}</b> → <b>{signal}</b>\n"
                    f"Price: {mid:.5f}\n"
                    f"RSI: {a.get('rsi_14')}\n"
                    f"Reason: {a['summary']}"
                )
                print(f"\n*** ALERT: {symbol} {signal} ***")
                send_telegram(msg)
                last_signals[symbol] = signal

        # Big move alert
        if mid is not None and symbol in last_prices:
            prev_price = last_prices[symbol]
            change_pct = abs((mid - prev_price) / prev_price * 100)
            if change_pct >= MIN_MOVE_PERCENT_ALERT:
                direction = "UP 📈" if mid > prev_price else "DOWN 📉"
                msg = f"⚡ {symbol} moved {change_pct:.2f}% {direction} → {mid:.5f}"
                print(f"\n*** MOVE ALERT: {msg} ***")
                send_telegram(msg)

        if mid is not None:
            last_prices[symbol] = mid


def main():
    print("Starting Forex Analyzer...")
    print(f"Monitoring: {', '.join(PAIRS)}")
    print(f"Check interval: {CHECK_INTERVAL_SECONDS} seconds")
    print("Press Ctrl+C to stop\n")

    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        print("Telegram alerts: ENABLED")
    else:
        print("Telegram alerts: disabled (set TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID to enable)")

    while True:
        try:
            analyses = []
            for pair in PAIRS:
                print(f"Analyzing {pair}...", end=" ", flush=True)
                a = analyze_pair(pair)
                analyses.append(a)
                print("done")
                time.sleep(0.3)  # be nice to the free API

            report = format_report(analyses)
            print("\n" + report)

            check_for_alerts(analyses)

            print(f"\nNext check in {CHECK_INTERVAL_SECONDS} seconds...\n")
            time.sleep(CHECK_INTERVAL_SECONDS)

        except KeyboardInterrupt:
            print("\nStopped by user. Goodbye!")
            break
        except Exception as e:
            print(f"\nUnexpected error: {e}")
            print("Retrying in 30 seconds...")
            time.sleep(30)


if __name__ == "__main__":
    main()
